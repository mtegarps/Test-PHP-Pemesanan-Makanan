<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-white text-center" style="background-color: #f57c00!important;">
                    <h6>Detail Pesanan dengan Nomor Meja <?php echo e($orders->first()->tableNumber); ?></h6>
                    <p>Waktu pemesanan : <?php echo e(date('d-m-Y H:i:s', strtotime($orders->first()->orderDate))); ?>  <?php echo e(Auth::user()->role==62 ? 'dibuat oleh '.$orders->first()->createdBy : ''); ?></p>
                </div>

                <div class="card-body">
                    <?php if($message=Session::get('message')): ?>
                        <div class="alert alert-primary alert-dismissible fade show" role="alert">
                                <?php echo e($message); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>                                     
                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            Gagal mengedit pesanan. Data yang dikirim tidak valid.
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>                                     
                        </div>
                    <?php endif; ?>
                    <?php if($orders->first()->orderStatus == 'Belum dibayar'): ?>
                    <form id="formEditTable" method="post" class="form-inline mb-3" action="<?php echo e(url('/order/table/update')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="id" id="id" value="<?php echo e($id); ?>">
                        <label for="edit_table_number" class="mr-2">Nomor Meja</label>
                        <select class="form-control mr-sm-2" id="edit_table_number" name="edit_table_number">
                            <option value="<?php echo e($orders->first()->tableID); ?>" selected><?php echo e($orders->first()->tableNumber); ?></option>
                            <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($t->uid); ?>"><?php echo e($t->table_number); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button type="submit" class="btn btn-primary my-2 my-sm-0">Ubah</button>
                    </form>
                    <form id="formAddOrder" method="post" class="form-inline mb-3" action="<?php echo e(url('order/add/'.$id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <label for="add_new_menu" class="mr-2">Menu</label>
                        <select class="form-control mr-sm-2 <?php echo e($errors->has('add_new_menu') ? ' is-invalid' : ''); ?>" id="add_new_menu" name="add_new_menu">
                            <option value="" selected>-- Pilih Menu -- </option>
                            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($m->uid); ?>"><?php echo e($m->menu_name); ?> ( Rp. <?php echo e(number_format($m->menu_price,0,',','.')); ?> )</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('add_new_menu')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('add_new_menu')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <label for="quantity_new_menu" class="mr-2">Jumlah</label>
                        <input type="number" class="form-control mr-sm-2 <?php echo e($errors->has('quantity_new_menu') ? ' is-invalid' : ''); ?>" id="quantity_new_menu" name="quantity_new_menu" min="1" max="100">
                        <?php if($errors->has('quantity_new_menu')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('quantity_new_menu')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <button type="submit" class="btn my-2 my-sm-0" style="background-color: #76ff03!important;">Tambah Pesanan</button>
                    </form>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-hover table-striped table-bordered" id="orderDetailDataTable">
                            <thead class="bg-dark text-white">
                                <th>No.</th>
                                <th>Menu</th>
                                <th>Harga</th>
                                <th>Jumlah</th>
                                <?php if($orders->first()->orderStatus == 'Belum dibayar'): ?>
                                <th>Aksi</th>
                                <?php endif; ?>
                            </thead>
                            <tbody id="orderDetailData">
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$no); ?></td>
                                    <td><?php echo e($o->menuName); ?></td>
                                    <td>Rp. <?php echo e(number_format($o->menuPrice,0,',','.')); ?></td>
                                    <td><?php echo e($o->quantityOrdered); ?></td>
                                    <?php if($orders->first()->orderStatus == 'Belum dibayar'): ?>
                                    <td>
                                        <button type="button" class="btn btn-sm text-white" style="background-color: #00897b!important;" data-toggle="modal" data-target="#editMenuOrdered" menuID="<?php echo e($o->menuID); ?>" menuName="<?php echo e($o->menuName); ?>" id="editOrderedMenu" quantityOrdered="<?php echo e($o->quantityOrdered); ?>" orderDetailsID="<?php echo e($o->orderDetailsID); ?>" >Edit</button>
                                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#cancelMenuOrdered" menuName="<?php echo e($o->menuName); ?>" id="cancelOrderedMenu" quantityOrdered="<?php echo e($o->quantityOrdered); ?>" orderDetailsID="<?php echo e($o->orderDetailsID); ?>" >Batalkan</button>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <h5>Total Pembayaran : Rp. <?php echo e(number_format($orders->first()->totalPrice,0,',','.')); ?>

                    <?php if($orders->first()->orderStatus== 'Belum dibayar'): ?>
                    (<strong class="text-warning">Belum dibayar</strong>)
                    <?php elseif($orders->first()->orderStatus== 'Telah dibayar'): ?>
                    (<strong class="text-info">Telah dibayar</strong>)
                    <a href="<?php echo e(url('invoice/'.$paymentID)); ?>" class="btn btn-primary btn-sm text-white" target="__blank">Cetak Bukti Pembayaran</a>
                    <?php else: ?>
                    (<strong class="text-danger">Dibatalkan</strong>)
                    <?php endif; ?>
                    </h5>
                    <?php if($orders->first()->orderStatus == 'Belum dibayar' && Auth::user()->role== 62): ?>
                    <a class="btn text-white" href="<?php echo e(url('admin/payment/'.$crypted_order_uid.'/create')); ?>" style="background-color: #6d4c41!important;">
                        Buat Pembayaran
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if($orders->first()->orderStatus == 'Belum dibayar'): ?>
<!-- Add Order Modal -->
<div class="modal fade" id="editMenuOrdered" tabindex="-1" role="dialog" aria-labelledby="editMenuOrderedLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #00897b!important;">
        <h5 class="modal-title text-white" id="editMenuOrderedLabel">Edit Pesanan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" id="updateMenuOrdered">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="edit_menu_ordered_id" class="col-form-label">Menu Pesanan</label>
                <select class="form-control" id="edit_menu_ordered_id" name="edit_menu_ordered_id" required>
                </select>
            </div>
            <div class="form-group">
                <label for="edit_quantity_menu_ordered" class="col-form-label">Jumlah</label>
                <input type="number" class="form-control" id="edit_quantity_menu_ordered" name="edit_quantity_menu_ordered" required min="1" max="100">
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-success text-white" id="saveOrderBtn">
            Update
        </button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- End Order Menu Modal -->
<!-- Delete Order Modal -->
<div class="modal fade" id="cancelMenuOrdered" tabindex="-1" role="dialog" aria-labelledby="cancelMenuOrderedLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header bg-danger">
        <h5 class="modal-title text-white" id="cancelMenuOrderedLabel">Batalkan Pesanan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="contentCancelModal">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <form method="post" style="display: inline;" id="cancelOrderedForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Batalkan</button>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- End Delete Order Modal -->
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php if($orders->first()->orderStatus == 'Belum dibayar'): ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            // Edit
            $(document).on('click', '#editOrderedMenu', function(){
                const menuID = $(this).attr('menuID');
                const quantityOrdered = $(this).attr('quantityOrdered');
                const orderDetailsID = $(this).attr('orderDetailsID');
                $('#edit_menu_ordered_id').html(`
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->uid); ?>" ${menuID==`<?php echo e($m->uid); ?>` ? 'selected' : ''} ><?php echo e($m->menu_name); ?> ( Rp. <?php echo e(number_format($m->menu_price,0,',','.')); ?> )</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    `); 
                $('#edit_quantity_menu_ordered').val(quantityOrdered);
                $('#updateMenuOrdered').attr('action', `<?php echo e(url('order/update/'.$id.'/${orderDetailsID}')); ?>`);
            });
            // Delete
            $(document).on('click', '#cancelOrderedMenu', function(){
                const menuName = $(this).attr('menuName');
                const quantityOrdered = $(this).attr('quantityOrdered');
                const orderDetailsID = $(this).attr('orderDetailsID');
                $('#contentCancelModal').html(`<p>Batalkan pemesanan menu <strong>${menuName} (${quantityOrdered} porsi)</strong> ? </p>`);
                $('#cancelOrderedForm').attr('action', `<?php echo e(url('order/destroy/'.$id.'/${orderDetailsID}')); ?>`);
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>