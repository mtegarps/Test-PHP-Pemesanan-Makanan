<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"> <h4 class="text-center">Dashboard</h4></div>

                <div class="card-body bg-dark">
                    <div class="card-deck">
                        <div class="card text-white bg-primary mb-3">
                          <div class="card-header"><h4 class="card-title text-center">Total pendapatan sementara pada hari ini</h4></div>
                          <div class="card-body">
                            <h2 class="card-title text-center">Rp <?php echo e(number_format($totalPayment[0]->paymentToday, 0,',','.')); ?></h2>
                          </div>
                        </div>
                        <div class="card text-white bg-danger mb-3">
                          <div class="card-header"><h4 class="card-title text-center">Menu yang paling sering dipesan</h4></div>
                          <div class="card-body">
                            <ol>
                                <?php $__currentLoopData = $topFoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <li><?php echo e($f->menu_name); ?> ( <?php echo e($f->total); ?> )</li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>