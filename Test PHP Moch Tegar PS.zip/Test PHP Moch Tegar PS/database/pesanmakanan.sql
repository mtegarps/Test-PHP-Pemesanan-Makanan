-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2021 at 09:25 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pesanmakanan`
--

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT uuid(),
  `menu_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_price` double NOT NULL,
  `status_stock` enum('Tersedia','Tidak tersedia') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`uid`, `menu_name`, `menu_price`, `status_stock`, `created_at`, `updated_at`) VALUES
('036481a7-3ebd-11ec-adac-74d02be4fe12', 'Jus Alpukat', 10000, 'Tersedia', '2021-11-06 04:50:06', '2021-11-06 04:50:06'),
('ea0a0e30-3ebc-11ec-adac-74d02be4fe12', 'Nasi Goreng', 15000, 'Tersedia', '2021-11-06 04:49:24', '2021-11-06 04:49:24'),
('f34b2c23-3ebc-11ec-adac-74d02be4fe12', 'Mie Ayam', 10000, 'Tersedia', '2021-11-06 04:49:39', '2021-11-06 04:49:39'),
('fc15ead9-3ebc-11ec-adac-74d02be4fe12', 'Lemon Tea', 7000, 'Tersedia', '2021-11-06 04:49:54', '2021-11-06 04:49:54');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2020_11_14_033944_create_menus_table', 1),
(3, '2020_11_14_034201_create_orders_table', 1),
(4, '2020_11_14_034704_create_payments_table', 1),
(5, '2020_11_21_111417_create_order_details_table', 1),
(6, '2020_11_21_112249_create_tables_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT uuid(),
  `created_by` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_number` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_price` double(8,2) UNSIGNED NOT NULL,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Belum dibayar','Telah dibayar','Dibatalkan') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`uid`, `created_by`, `table_number`, `total_price`, `invoice_number`, `status`, `created_at`, `updated_at`) VALUES
('5adb2bb2-3ebd-11ec-adac-74d02be4fe12', '7ca60db6-3ebc-11ec-adac-74d02be4fe12', '7ca6bf9a-3ebc-11ec-adac-74d02be4fe12', 20000.00, '20211106115233', 'Telah dibayar', '2021-11-06 04:52:33', '2021-11-06 06:31:38'),
('82137be5-3ec8-11ec-adac-74d02be4fe12', '7ca60db6-3ebc-11ec-adac-74d02be4fe12', '7caa51fd-3ebc-11ec-adac-74d02be4fe12', 37000.00, '20211106131224', 'Telah dibayar', '2021-11-06 06:12:24', '2021-11-06 06:13:07'),
('f5b2973b-3ec4-11ec-adac-74d02be4fe12', '09cd4376-3ebe-11ec-adac-74d02be4fe12', '7ca72101-3ebc-11ec-adac-74d02be4fe12', 10000.00, '20211106124700', 'Telah dibayar', '2021-11-06 05:47:00', '2021-11-06 05:49:06');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT uuid(),
  `order_uid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `menu_uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity_ordered` smallint(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`uid`, `order_uid`, `menu_uid`, `quantity_ordered`, `created_at`, `updated_at`) VALUES
('5adc2edc-3ebd-11ec-adac-74d02be4fe12', '5adb2bb2-3ebd-11ec-adac-74d02be4fe12', '036481a7-3ebd-11ec-adac-74d02be4fe12', 1, '2021-11-06 04:52:33', '2021-11-06 04:52:33'),
('5adc87f0-3ebd-11ec-adac-74d02be4fe12', '5adb2bb2-3ebd-11ec-adac-74d02be4fe12', 'f34b2c23-3ebc-11ec-adac-74d02be4fe12', 1, '2021-11-06 04:52:33', '2021-11-06 04:52:33'),
('8215d40c-3ec8-11ec-adac-74d02be4fe12', '82137be5-3ec8-11ec-adac-74d02be4fe12', 'fc15ead9-3ebc-11ec-adac-74d02be4fe12', 1, '2021-11-06 06:12:24', '2021-11-06 06:12:24'),
('8216a615-3ec8-11ec-adac-74d02be4fe12', '82137be5-3ec8-11ec-adac-74d02be4fe12', 'ea0a0e30-3ebc-11ec-adac-74d02be4fe12', 2, '2021-11-06 06:12:24', '2021-11-06 06:12:24'),
('f5b4ab56-3ec4-11ec-adac-74d02be4fe12', 'f5b2973b-3ec4-11ec-adac-74d02be4fe12', '036481a7-3ebd-11ec-adac-74d02be4fe12', 1, '2021-11-06 05:47:00', '2021-11-06 05:47:00');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT uuid(),
  `order_uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(8,2) NOT NULL,
  `moneyPaid` double(8,2) NOT NULL,
  `moneyTurn` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`uid`, `order_uid`, `amount`, `moneyPaid`, `moneyTurn`, `created_at`, `updated_at`) VALUES
('32135e88-3ecb-11ec-adac-74d02be4fe12', '5adb2bb2-3ebd-11ec-adac-74d02be4fe12', 20000.00, 50000.00, 30000.00, '2021-11-06 06:31:38', '2021-11-06 06:31:38'),
('411040eb-3ec5-11ec-adac-74d02be4fe12', 'f5b2973b-3ec4-11ec-adac-74d02be4fe12', 10000.00, 50000.00, 40000.00, '2021-11-06 05:49:06', '2021-11-06 05:49:06'),
('9c12fc00-3ec8-11ec-adac-74d02be4fe12', '82137be5-3ec8-11ec-adac-74d02be4fe12', 37000.00, 50000.00, 13000.00, '2021-11-06 06:13:07', '2021-11-06 06:13:07');

-- --------------------------------------------------------

--
-- Table structure for table `tables`
--

CREATE TABLE `tables` (
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT uuid(),
  `table_number` tinyint(4) NOT NULL,
  `status` enum('Kosong','Telah dipesan') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tables`
--

INSERT INTO `tables` (`uid`, `table_number`, `status`, `created_at`, `updated_at`) VALUES
('7ca6bf9a-3ebc-11ec-adac-74d02be4fe12', 1, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 06:31:38'),
('7ca72101-3ebc-11ec-adac-74d02be4fe12', 2, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 05:49:06'),
('7ca7b2e4-3ebc-11ec-adac-74d02be4fe12', 3, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7ca83d5d-3ebc-11ec-adac-74d02be4fe12', 4, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7ca8bbf4-3ebc-11ec-adac-74d02be4fe12', 5, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7ca94c7d-3ebc-11ec-adac-74d02be4fe12', 6, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7ca9d633-3ebc-11ec-adac-74d02be4fe12', 7, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7caa51fd-3ebc-11ec-adac-74d02be4fe12', 8, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 06:13:07'),
('7caad0c4-3ebc-11ec-adac-74d02be4fe12', 9, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7cab3bba-3ebc-11ec-adac-74d02be4fe12', 10, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7cab9f30-3ebc-11ec-adac-74d02be4fe12', 11, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7cac0c4f-3ebc-11ec-adac-74d02be4fe12', 12, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7cac5a23-3ebc-11ec-adac-74d02be4fe12', 13, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7cacd197-3ebc-11ec-adac-74d02be4fe12', 14, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7cad13e9-3ebc-11ec-adac-74d02be4fe12', 15, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7cad7b35-3ebc-11ec-adac-74d02be4fe12', 16, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7cadbcb7-3ebc-11ec-adac-74d02be4fe12', 17, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7cae28dd-3ebc-11ec-adac-74d02be4fe12', 18, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7cae693c-3ebc-11ec-adac-74d02be4fe12', 19, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20'),
('7caedcce-3ebc-11ec-adac-74d02be4fe12', 20, 'Kosong', '2021-11-06 04:46:20', '2021-11-06 04:46:20');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT uuid(),
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` smallint(6) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `name`, `email`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
('09cd4376-3ebe-11ec-adac-74d02be4fe12', 'Asep Sudrajat', 'asep@kafe.com', '$2y$10$QUekZCAJg7zqkLg1PlhQgOfnRRtghaULTA6OicR3OuvMZ7TNl7bFm', 26, 'xMjdSDa6rSe2pUmQEfWgOqaCMF7LrcH44Cp25ugtk4n8sotXbp0DHLjpZ45Q', '2021-11-06 04:57:27', '2021-11-06 04:57:27'),
('7ca60db6-3ebc-11ec-adac-74d02be4fe12', 'Owner', 'admin@kafe.com', '$2y$10$IbMgWzhP04HBpZWRlx18pOCo1KVQRc1drKo2QB.qgw/osyUIjQbn2', 62, 'TBV83LlWJ5FEBPyMeqLDuxWDEAPZPKGWIv4b3JCcJxtBJrx4W4yyDczMqWiv', '2021-11-06 04:46:20', '2021-11-06 04:46:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `tables`
--
ALTER TABLE `tables`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
